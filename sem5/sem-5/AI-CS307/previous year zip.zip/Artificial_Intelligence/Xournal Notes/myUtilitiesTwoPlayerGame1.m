function [u] = myUtilitiesTwoPlayerGame1(studentID)

% studentID = 20185xyyy
% Enter your student ID
% Usage:
% u = myUtilitiesTwoPlayerGame1(203021001)

seed = 100 + mod(studentID, 10);

rand("seed",seed);
u = round(20*rand(1,16));

end
